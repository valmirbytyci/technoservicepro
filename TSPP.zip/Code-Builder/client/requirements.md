## Packages
recharts | Dashboard charts for financial and job data
date-fns | Date formatting for schedules and timestamps
framer-motion | Smooth transitions for dashboard elements and page loads
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Oswald", "sans-serif"],
}
