import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useJobs, useUpdateJob } from "@/hooks/use-jobs";
import { useAttendance, useCheckIn, useCheckOut } from "@/hooks/use-attendance";
import { LayoutShell } from "@/components/layout-shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/status-badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Clock, PlayCircle, CheckCircle2, Plus } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function WorkerDashboard() {
  const { user } = useAuth();
  const { data: jobs, isLoading: jobsLoading } = useJobs();
  const { data: attendance, isLoading: attendanceLoading } = useAttendance();
  const checkIn = useCheckIn();
  const checkOut = useCheckOut();
  const updateJob = useUpdateJob();

  const myJobs = jobs?.filter(job => job.assignedToId === user?.id) || [];
  const pendingJobs = myJobs.filter(j => j.status === 'not_started');
  const activeJobs = myJobs.filter(j => j.status === 'in_progress');
  const completedJobs = myJobs.filter(j => j.status === 'completed');

  const todayAttendance = attendance?.find(a => {
    return !a.checkOut;
  });
  const isCheckedIn = !!todayAttendance;

  if (jobsLoading || attendanceLoading) {
    return <div className="h-screen w-full flex items-center justify-center">Loading...</div>;
  }

  return (
    <LayoutShell title="My Dashboard">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className={cn(
          "border-l-4 shadow-lg transition-all",
          isCheckedIn ? "border-l-green-500 bg-green-50/50" : "border-l-slate-300"
        )}>
          <CardContent className="p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">
                {isCheckedIn ? "You are currently Checked In" : "You are currently Checked Out"}
              </h2>
              <p className="text-slate-500 mt-1">
                {isCheckedIn 
                  ? `Started shift at ${format(new Date(todayAttendance!.checkIn!), 'p')}`
                  : "Ready to start your shift?"}
              </p>
            </div>

            {isCheckedIn ? (
              <Button 
                size="lg" 
                variant="destructive" 
                className="w-full md:w-auto h-16 px-8 text-lg shadow-xl shadow-red-200"
                onClick={() => {
                  console.log("Attempting check out...");
                  checkOut.mutate();
                }}
                disabled={checkOut.isPending}
              >
                <Clock className="mr-2 h-6 w-6" /> Check Out
              </Button>
            ) : (
              <Button 
                size="lg" 
                className="w-full md:w-auto h-16 px-8 text-lg bg-green-600 hover:bg-green-700 shadow-xl shadow-green-200"
                onClick={() => {
                  console.log("Attempting check in...");
                  checkIn.mutate({ jobId: undefined });
                }}
                disabled={checkIn.isPending}
              >
                <Clock className="mr-2 h-6 w-6" /> Check In
              </Button>
            )}
          </CardContent>
        </Card>

        <Tabs defaultValue="active" className="space-y-4">
          <TabsList className="bg-white border p-1 w-full justify-start">
            <TabsTrigger value="active" className="flex-1 md:flex-none">Active ({activeJobs.length})</TabsTrigger>
            <TabsTrigger value="pending" className="flex-1 md:flex-none">Pending ({pendingJobs.length})</TabsTrigger>
            <TabsTrigger value="new-job" className="flex-1 md:flex-none">Create Job</TabsTrigger>
            <TabsTrigger value="mall" className="flex-1 md:flex-none">Mall/Stock</TabsTrigger>
            <TabsTrigger value="history" className="flex-1 md:flex-none">History</TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {activeJobs.length === 0 && (
              <div className="text-center py-12 bg-white rounded-lg border border-dashed">
                <p className="text-slate-500">No active jobs right now.</p>
              </div>
            )}
            {activeJobs.map(job => (
              <JobCard 
                key={job.id} 
                job={job} 
                actionLabel="Complete Job"
                onAction={() => updateJob.mutate({ id: job.id, status: 'completed' })}
                variant="active"
              />
            ))}
          </TabsContent>

          <TabsContent value="pending" className="space-y-4">
            {pendingJobs.map(job => (
              <JobCard 
                key={job.id} 
                job={job} 
                actionLabel="Start Job"
                onAction={() => updateJob.mutate({ id: job.id, status: 'in_progress' })}
                variant="pending"
              />
            ))}
          </TabsContent>

          <TabsContent value="new-job">
            <Card>
              <CardHeader>
                <CardTitle>Create New Job</CardTitle>
                <CardDescription>Self-assign a new task</CardDescription>
              </CardHeader>
              <CardContent>
                <WorkerCreateJobForm onSuccess={() => {}} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mall">
            <MallReturn />
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            {completedJobs.map(job => (
              <JobCard 
                key={job.id} 
                job={job} 
                variant="completed"
              />
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </LayoutShell>
  );
}

function MallReturn() {
  const { data: jobs } = useJobs();
  const { data: products } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const { user } = useAuth();
  const [selectedJob, setSelectedJob] = useState<string>("");
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [quantity, setQuantity] = useState("1");
  const [productSearch, setProductSearch] = useState("");

  const myJobs = jobs?.filter(j => j.assignedToId === user?.id && j.status !== 'completed') || [];

  const filteredProducts = products?.filter(p => 
    (p.name.toLowerCase().includes(productSearch.toLowerCase()) || 
     p.category?.toLowerCase().includes(productSearch.toLowerCase()))
  );

  const mutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/job-items", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setSelectedProduct("");
      setQuantity("1");
    }
  });

  const returnMutation = useMutation({
    mutationFn: (itemId: number) => apiRequest("PATCH", `/api/job-items/${itemId}`, { returned: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    }
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Receive Products</CardTitle>
          <CardDescription>Get items from mall for your current job</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Select Job</Label>
            <Select value={selectedJob} onValueChange={setSelectedJob}>
              <SelectTrigger><SelectValue placeholder="Choose job" /></SelectTrigger>
              <SelectContent>
                {myJobs.map(j => <SelectItem key={j.id} value={String(j.id)}>{j.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Search & Select Product</Label>
              <div className="flex gap-2">
                <Input 
                  placeholder="Search product..." 
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="flex-1"
                />
                <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger className="w-[200px]"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {filteredProducts?.map(p => (
                      <SelectItem key={p.id} value={String(p.id)}>{p.name} ({p.stockQuantity})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Quantity</Label>
              <Input type="number" min="1" value={quantity} onChange={e => setQuantity(e.target.value)} />
            </div>
          </div>
          <Button 
            className="w-full" 
            disabled={!selectedJob || !selectedProduct || mutation.isPending}
            onClick={() => mutation.mutate({
              jobId: parseInt(selectedJob),
              productId: parseInt(selectedProduct),
              quantity: parseInt(quantity)
            })}
          >
            Receive Items
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Return Products</CardTitle>
          <CardDescription>Return items to stock from your active jobs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {myJobs.filter((j: any) => j.items && j.items.length > 0).map((job: any) => (
              <div key={job.id} className="space-y-2">
                <h4 className="font-medium text-sm text-slate-500 uppercase tracking-wider">{job.title}</h4>
                <div className="grid gap-2">
                  {job.items.filter((item: any) => !item.returned).map((item: any) => (
                    <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg bg-white">
                      <div>
                        <p className="font-medium">{item.product?.name || 'Unknown Product'}</p>
                        <p className="text-sm text-slate-500">Quantity: {item.quantity}</p>
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => returnMutation.mutate(item.id)}
                        disabled={returnMutation.isPending}
                      >
                        Return to Stock
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            {myJobs.every((j: any) => !j.items || j.items.filter((i: any) => !i.returned).length === 0) && (
              <p className="text-center py-4 text-slate-500">No items to return.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function WorkerCreateJobForm({ onSuccess }: { onSuccess: () => void }) {
  const { user } = useAuth();
  const { data: products } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const [formData, setFormData] = useState({
    title: "",
    client: "",
    location: "",
    description: "",
  });
  const [selectedProducts, setSelectedProducts] = useState<{ id: number, quantity: number }[]>([]);
  const [productSearch, setProductSearch] = useState("");

  const filteredProducts = products?.filter(p => 
    (p.name.toLowerCase().includes(productSearch.toLowerCase()) || 
     p.category?.toLowerCase().includes(productSearch.toLowerCase()))
  );

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const job = await apiRequest("POST", "/api/jobs", data).then(res => res.json());
      for (const p of selectedProducts) {
        await apiRequest("POST", "/api/job-items", {
          jobId: job.id,
          productId: p.id,
          quantity: p.quantity
        });
      }
      return job;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setFormData({ title: "", client: "", location: "", description: "" });
      setSelectedProducts([]);
      onSuccess();
    }
  });

  const addProductToSelection = (id: string) => {
    const pid = parseInt(id);
    if (!selectedProducts.find(p => p.id === pid)) {
      setSelectedProducts([...selectedProducts, { id: pid, quantity: 1 }]);
    }
  };

  return (
    <form className="space-y-4" onSubmit={(e) => {
      e.preventDefault();
      mutation.mutate({ ...formData, assignedToId: user?.id, status: 'not_started' });
    }}>
      <div className="space-y-2">
        <Label>Job Title</Label>
        <Input required value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} />
      </div>
      
      <div className="space-y-4 p-4 border rounded-lg bg-slate-50">
        <div className="flex justify-between items-center">
          <Label className="text-slate-900 font-bold">Select Products for Job</Label>
        </div>
        
        <div className="flex gap-2">
          <Input 
            placeholder="Search products..." 
            value={productSearch}
            onChange={(e) => setProductSearch(e.target.value)}
            className="flex-1 bg-white"
          />
          <Select onValueChange={addProductToSelection}>
            <SelectTrigger className="bg-white w-[180px]">
              <SelectValue placeholder="Add..." />
            </SelectTrigger>
            <SelectContent>
              {filteredProducts?.map(p => (
                <SelectItem key={p.id} value={String(p.id)}>{p.name} ({p.stockQuantity})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          {selectedProducts.map((sp, idx) => {
            const product = products?.find(p => p.id === sp.id);
            return (
              <div key={sp.id} className="flex items-center justify-between bg-white p-2 border rounded">
                <span className="text-sm font-medium">{product?.name}</span>
                <div className="flex items-center gap-2">
                  <Input 
                    type="number" 
                    className="w-20 h-8" 
                    min="1" 
                    max={product?.stockQuantity}
                    value={sp.quantity} 
                    onChange={e => {
                      const newSelection = [...selectedProducts];
                      newSelection[idx].quantity = parseInt(e.target.value);
                      setSelectedProducts(newSelection);
                    }}
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-destructive"
                    onClick={() => setSelectedProducts(selectedProducts.filter(p => p.id !== sp.id))}
                  >
                    <Plus className="h-4 w-4 rotate-45" />
                  </Button>
                </div>
              </div>
            );
          })}
          {selectedProducts.length === 0 && <p className="text-xs text-slate-500 italic">No products selected yet.</p>}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Client</Label>
          <Input value={formData.client} onChange={e => setFormData({ ...formData, client: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Location</Label>
          <Input value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })} />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Input value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} />
      </div>
      <Button type="submit" className="w-full" disabled={mutation.isPending}>
        {mutation.isPending ? "Creating..." : "Create & Assign Job"}
      </Button>
    </form>
  );
}

function JobCard({ job, actionLabel, onAction, variant }: any) {
  const isPending = variant === 'pending';
  const isActive = variant === 'active';
  const { data: products } = useQuery<any[]>({ queryKey: ["/api/products"] });

  return (
    <Card className={cn(
      "overflow-hidden transition-all hover:shadow-md",
      isActive && "border-blue-200 bg-blue-50/30"
    )}>
      <div className={cn("h-1.5 w-full", 
        isActive ? "bg-blue-500" : isPending ? "bg-slate-300" : "bg-green-500"
      )} />
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-4 justify-between">
          <div className="space-y-3 flex-1">
            <div>
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-slate-900">{job.title}</h3>
                <StatusBadge status={job.status} />
              </div>
              <p className="text-slate-600 mt-1">{job.description || "No description provided."}</p>
            </div>
            
            <div className="flex flex-wrap gap-4 text-sm text-slate-500">
              {job.client && (
                <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded border">
                  <span className="font-semibold text-slate-700">Client:</span> {job.client}
                </div>
              )}
              {job.location && (
                <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded border">
                  <MapPin className="w-3.5 h-3.5" /> {job.location}
                </div>
              )}
            </div>

            {/* Products List in Card */}
            {job.items && job.items.length > 0 && (
              <div className="mt-4 space-y-2">
                <p className="text-xs font-bold text-slate-400 uppercase">Assigned Products:</p>
                <div className="flex flex-wrap gap-2">
                  {job.items.map((item: any) => (
                    <div key={item.id} className="text-xs bg-slate-100 px-2 py-1 rounded border flex items-center gap-2">
                      <span>{item.product?.name || 'Item'} (x{item.quantity})</span>
                      {item.returned && <span className="text-[10px] text-orange-600 font-bold underline">Returned</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {actionLabel && onAction && (
            <div className="flex items-center md:justify-end shrink-0">
              <Button 
                onClick={onAction}
                className={cn(
                  "w-full md:w-auto",
                  isActive ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"
                )}
              >
                {isActive ? <CheckCircle2 className="mr-2 h-4 w-4" /> : <PlayCircle className="mr-2 h-4 w-4" />}
                {actionLabel}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
