import { db } from "./db";
import {
  users, jobs, attendance, transactions, products, jobItems,
  type User, type InsertUser,
  type Job, type InsertJob,
  type Attendance, type InsertAttendance,
  type Transaction, type InsertTransaction,
  type Product, type InsertProduct,
  type JobItem, type InsertJobItem
} from "@shared/schema";
import { eq, desc, and, isNull } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;

  // Jobs
  getJobs(): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, updates: Partial<InsertJob>): Promise<Job>;

  // Attendance
  checkIn(userId: number, jobId?: number): Promise<Attendance>;
  checkOut(userId: number): Promise<Attendance>;
  getAttendance(userId?: number): Promise<Attendance[]>;
  getActiveCheckIn(userId: number): Promise<Attendance | undefined>;

  // Transactions
  getTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Products & Mall
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;
  
  // Job Items (Stock Tracking)
  createJobItem(item: InsertJobItem): Promise<JobItem>;
  updateJobItem(id: number, updates: Partial<JobItem>): Promise<JobItem>;
  
  // Session store helpers
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values([insertUser as any]).returning();
    return user;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Jobs
  async getJobs(): Promise<Job[]> {
    return await db.query.jobs.findMany({
      orderBy: desc(jobs.createdAt),
      with: {
        assignedTo: true,
        items: {
          with: {
            product: true
          }
        }
      }
    });
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values([insertJob as any]).returning();
    return job;
  }

  async updateJob(id: number, updates: Partial<InsertJob>): Promise<Job> {
    const [job] = await db.update(jobs).set(updates as any).where(eq(jobs.id, id)).returning();
    return job;
  }

  // Attendance
  async checkIn(userId: number, jobId?: number): Promise<Attendance> {
    const [record] = await db.insert(attendance).values([{
      userId,
      jobId,
      checkIn: new Date(),
    }]).returning();
    return record;
  }

  async checkOut(userId: number): Promise<Attendance> {
    // Find active check-in
    const [active] = await db.select().from(attendance)
      .where(and(eq(attendance.userId, userId), isNull(attendance.checkOut)))
      .orderBy(desc(attendance.checkIn))
      .limit(1);

    if (!active) {
      throw new Error("No active check-in found");
    }

    const checkOutTime = new Date();
    const durationMs = checkOutTime.getTime() - active.checkIn!.getTime();
    const hours = (durationMs / (1000 * 60 * 60)).toFixed(2);

    const [record] = await db.update(attendance)
      .set({ checkOut: checkOutTime, totalHours: hours })
      .where(eq(attendance.id, active.id))
      .returning();
    
    return record;
  }

  async getAttendance(userId?: number): Promise<any[]> {
    if (userId) {
      return await db.query.attendance.findMany({
        where: eq(attendance.userId, userId),
        orderBy: desc(attendance.checkIn),
        with: { user: true }
      });
    }
    return await db.query.attendance.findMany({
      orderBy: desc(attendance.checkIn),
      with: { user: true }
    });
  }

  async getActiveCheckIn(userId: number): Promise<Attendance | undefined> {
    const [active] = await db.select().from(attendance)
      .where(and(eq(attendance.userId, userId), isNull(attendance.checkOut)))
      .orderBy(desc(attendance.checkIn))
      .limit(1);
    return active;
  }

  // Transactions
  async getTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions).orderBy(desc(transactions.date));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [tx] = await db.insert(transactions).values([insertTransaction as any]).returning();
    return tx;
  }

  // Products & Mall
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [prod] = await db.select().from(products).where(eq(products.id, id));
    return prod;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [prod] = await db.insert(products).values([insertProduct]).returning();
    return prod;
  }

  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product> {
    const [prod] = await db.update(products).set(updates as any).where(eq(products.id, id)).returning();
    return prod;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Job Items (Stock Tracking)
  async createJobItem(insertItem: InsertJobItem): Promise<JobItem> {
    // Decrement stock
    const prod = await this.getProduct(insertItem.productId);
    if (prod) {
      await this.updateProduct(prod.id, { 
        stockQuantity: Math.max(0, prod.stockQuantity - insertItem.quantity) 
      });
    }
    const [item] = await db.insert(jobItems).values([insertItem]).returning();
    return item;
  }

  async updateJobItem(id: number, updates: Partial<JobItem>): Promise<JobItem> {
    const [item] = await db.update(jobItems).set(updates as any).where(eq(jobItems.id, id)).returning();
    
    // If returned, increment stock
    if (updates.returned) {
      const prod = await this.getProduct(item.productId);
      if (prod) {
        await this.updateProduct(prod.id, { 
          stockQuantity: prod.stockQuantity + item.quantity 
        });
      }
    }
    return item;
  }
}

export const storage = new DatabaseStorage();
