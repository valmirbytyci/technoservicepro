import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { User } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication (passport, session)
  setupAuth(app);

  // === JOBS ROUTES ===
  app.get(api.jobs.list.path, async (req, res) => {
    const jobsList = await storage.getJobs();
    res.json(jobsList);
  });

  app.get(api.jobs.get.path, async (req, res) => {
    const job = await storage.getJob(Number(req.params.id));
    if (!job) return res.status(404).json({ message: "Job not found" });
    res.json(job);
  });

  app.post(api.jobs.create.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      const schema = api.jobs.create.input.extend({
        paymentAmount: z.preprocess((val) => {
          if (val === "" || val === undefined) return "0";
          return String(val);
        }, z.string()),
        assignedToId: z.preprocess((val) => {
          if (val === "" || val === undefined) return undefined;
          return Number(val);
        }, z.number().optional()),
      });
      const input = schema.parse(req.body);
      const job = await storage.createJob(input);
      res.status(201).json(job);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json(e.errors);
      }
      throw e;
    }
  });

  app.patch(api.jobs.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const jobId = Number(req.params.id);
    const updates = req.body;
    
    const oldJob = await storage.getJob(jobId);
    const job = await storage.updateJob(jobId, updates);
    
    // If job status changed to completed, create income transaction
    if (updates.status === 'completed' && oldJob?.status !== 'completed') {
      const items = (job as any).items || [];
      let totalProductValue = 0;
      for (const item of items) {
        if (item.product && !item.returned) {
          totalProductValue += Number(item.product.price) * item.quantity;
        }
      }
      
      if (totalProductValue > 0) {
        await storage.createTransaction({
          type: "income",
          amount: totalProductValue.toString(),
          description: `Revenue from completed job: ${job.title}`,
          date: new Date(),
          jobId: jobId
        });
      }
    }
    
    res.json(job);
  });

  app.post(api.attendance.checkIn.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const active = await storage.getActiveCheckIn((req.user as User).id);
    if (active) {
      return res.status(400).json({ message: "Already checked in" });
    }
    const record = await storage.checkIn((req.user as User).id, req.body.jobId);
    res.status(201).json(record);
  });

  app.post(api.attendance.checkOut.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const record = await storage.checkOut((req.user as User).id);
      res.json(record);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.get(api.attendance.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as User;
    const records = await storage.getAttendance(user.role === 'worker' ? user.id : undefined);
    res.json(records);
  });

  app.get("/api/attendance/all", async (req, res) => {
    if (!req.isAuthenticated() || (req.user as User).role !== 'admin') {
      return res.sendStatus(403);
    }
    const allAttendance = await storage.getAttendance();
    res.json(allAttendance);
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || (req.user as User).role !== 'admin') {
      return res.sendStatus(403);
    }
    await storage.deleteProduct(parseInt(req.params.id));
    res.sendStatus(200);
  });

  app.get("/api/products", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const prods = await storage.getProducts();
    res.json(prods);
  });

  app.post("/api/products", async (req, res) => {
    if (!req.isAuthenticated() || (req.user as User).role !== 'admin') return res.sendStatus(403);
    const prod = await storage.createProduct(req.body);
    res.status(201).json(prod);
  });

  app.post("/api/job-items", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const item = await storage.createJobItem(req.body);
    res.status(201).json(item);
  });

  app.patch("/api/job-items/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const item = await storage.updateJobItem(Number(req.params.id), req.body);
    res.json(item);
  });

  app.get(api.transactions.list.path, async (req, res) => {
    if (!req.isAuthenticated() || (req.user as User).role !== 'admin') return res.sendStatus(403);
    const txs = await storage.getTransactions();
    res.json(txs);
  });

  app.post(api.transactions.create.path, async (req, res) => {
    if (!req.isAuthenticated() || (req.user as User).role !== 'admin') return res.sendStatus(403);
    const schema = api.transactions.create.input.extend({
      amount: z.preprocess((val) => {
        if (val === "" || val === undefined) return "0";
        return String(val);
      }, z.string()),
    });
    const input = schema.parse(req.body);
    const tx = await storage.createTransaction(input);
    res.status(201).json(tx);
  });

  app.get(api.users.list.path, async (req, res) => {
    const usersList = await storage.getUsers();
    res.json(usersList);
  });

  app.post(api.users.create.path, async (req, res) => {
    if (req.isAuthenticated() && (req.user as User).role !== 'admin') {
      return res.sendStatus(403);
    }
    const user = await storage.createUser(req.body);
    res.status(201).json(user);
  });

  await seed();

  return httpServer;
}

// Helper to seed data
export async function seed() {
  const existing = await storage.getUserByUsername("admin");
  if (!existing) {
    await storage.createUser({
      username: "admin",
      password: "adminpassword", // In production, hash this!
      role: "admin",
      name: "System Admin",
      active: true,
    });
    
    await storage.createUser({
      username: "worker1",
      password: "workerpassword",
      role: "worker",
      name: "John Worker",
      active: true,
    });

    console.log("Seeded default users: admin/adminpassword, worker1/workerpassword");
  }
}
