import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").$type<"admin" | "worker">().notNull().default("worker"),
  name: text("name").notNull(),
  active: boolean("active").notNull().default(true),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  sku: text("sku").unique(),
  price: numeric("price").notNull().default("0"),
  stockQuantity: integer("stock_quantity").notNull().default(0),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  location: text("location"),
  client: text("client"), 
  supplier: text("supplier"), 
  status: text("status").$type<"not_started" | "in_progress" | "completed">().notNull().default("not_started"),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  paymentAmount: numeric("payment_amount").notNull().default("0"),
  assignedToId: integer("assigned_to_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobItems = pgTable("job_items", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => jobs.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  quantity: integer("quantity").notNull(),
  returned: boolean("returned").notNull().default(false),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  jobId: integer("job_id").references(() => jobs.id),
  checkIn: timestamp("check_in").notNull().defaultNow(),
  checkOut: timestamp("check_out"),
  totalHours: numeric("total_hours"),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: text("type").$type<"income" | "expense">().notNull(),
  amount: numeric("amount").notNull(),
  date: timestamp("date").defaultNow(),
  jobId: integer("job_id").references(() => jobs.id),
  description: text("description"),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  jobs: many(jobs),
  attendance: many(attendance),
}));

export const productsRelations = relations(products, ({ many }) => ({
  jobItems: many(jobItems),
}));

export const jobsRelations = relations(jobs, ({ one, many }) => ({
  assignedTo: one(users, {
    fields: [jobs.assignedToId],
    references: [users.id],
  }),
  items: many(jobItems),
  attendance: many(attendance),
  transactions: many(transactions),
}));

export const jobItemsRelations = relations(jobItems, ({ one }) => ({
  job: one(jobs, {
    fields: [jobItems.jobId],
    references: [jobs.id],
  }),
  product: one(products, {
    fields: [jobItems.productId],
    references: [products.id],
  }),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  user: one(users, {
    fields: [attendance.userId],
    references: [users.id],
  }),
  job: one(jobs, {
    fields: [attendance.jobId],
    references: [jobs.id],
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  job: one(jobs, {
    fields: [transactions.jobId],
    references: [jobs.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertJobSchema = createInsertSchema(jobs).omit({ id: true, createdAt: true });
export const insertJobItemSchema = createInsertSchema(jobItems).omit({ id: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true, totalHours: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });

// === EXPLICIT API CONTRACT TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export type JobItem = typeof jobItems.$inferSelect;
export type InsertJobItem = z.infer<typeof insertJobItemSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

// Auth types
export type LoginRequest = { username: string; password: string };
export type AuthResponse = User;
