import React, { useState } from "react";
import { LayoutShell } from "@/components/layout-shell";
import { useJobs, useCreateJob, useUpdateJob } from "@/hooks/use-jobs";
import { useUsers, useCreateUser } from "@/hooks/use-users";
import { useTransactions } from "@/hooks/use-transactions";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  Plus, Search, Briefcase, Users, DollarSign, Activity, 
  Calendar as CalendarIcon, MapPin, Building2, Package, ShoppingBag,
  Clock, CheckCircle, XCircle, ArrowLeftRight
} from "lucide-react";
import { format, isSameDay } from "date-fns";
import { cn } from "@/lib/utils";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell 
} from 'recharts';
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";

function MallManagement() {
  const { data: products, isLoading } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  if (isLoading) return <div>Loading mall...</div>;

  const filteredProducts = products?.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.sku?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
          <div className="flex justify-between items-center gap-4">
            <h3 className="text-xl font-bold">Inventory Management</h3>
            <div className="flex-1 max-w-sm relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input 
                placeholder="Search inventory..." 
                className="pl-9" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                  <Button><Plus className="mr-2 h-4 w-4" /> Add Product</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                  </DialogHeader>
                  <AddProductForm onSuccess={() => setOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {filteredProducts?.map(p => (
          <Card key={p.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg">{p.name}</CardTitle>
                    {p.category && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">{p.category}</span>}
                  </div>
                  <CardDescription>{p.sku || 'No SKU'}</CardDescription>
                </div>
                <div className="flex gap-1">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Product: {p.name}</DialogTitle>
                      </DialogHeader>
                      <form className="space-y-4" onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        const data = {
                          name: formData.get("name") as string,
                          price: formData.get("price") as string,
                          stockQuantity: parseInt(formData.get("stockQuantity") as string),
                          category: formData.get("category") as string,
                          sku: formData.get("sku") as string,
                        };
                        apiRequest("PATCH", `/api/products/${p.id}`, data).then(() => {
                          queryClient.invalidateQueries({ queryKey: ["/api/products"] });
                        });
                      }}>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Name</Label>
                            <Input name="name" defaultValue={p.name} />
                          </div>
                          <div className="space-y-2">
                            <Label>Category</Label>
                            <Input name="category" defaultValue={p.category} />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Price</Label>
                            <Input name="price" type="number" step="0.01" defaultValue={p.price} />
                          </div>
                          <div className="space-y-2">
                            <Label>Stock</Label>
                            <Input name="stockQuantity" type="number" defaultValue={p.stockQuantity} />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>SKU</Label>
                          <Input name="sku" defaultValue={p.sku} />
                        </div>
                        <Button type="submit" className="w-full">Update Product</Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-destructive"
                    onClick={() => {
                      if (confirm("Are you sure you want to delete this product?")) {
                        apiRequest("DELETE", `/api/products/${p.id}`).then(() => {
                          queryClient.invalidateQueries({ queryKey: ["/api/products"] });
                        });
                      }
                    }}
                  >
                    <Plus className="h-4 w-4 rotate-45" />
                  </Button>
                  <ShoppingBag className="h-4 w-4 text-slate-400 mt-2" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-2xl font-bold">{p.stockQuantity}</p>
                  <p className="text-xs text-slate-500">In Stock</p>
                </div>
                <div className="text-right">
                  <p className="font-mono font-medium text-slate-900">${p.price}</p>
                  <p className="text-xs text-slate-500">Price</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function AddProductForm({ onSuccess }: { onSuccess: () => void }) {
  const [formData, setFormData] = useState({ name: "", description: "", category: "", price: "", stockQuantity: "0", sku: "" });
  const mutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/products", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      onSuccess();
    }
  });

  return (
    <form className="space-y-4" onSubmit={(e) => {
      e.preventDefault();
      mutation.mutate({ ...formData, price: formData.price.toString(), stockQuantity: parseInt(formData.stockQuantity) });
    }}>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Product Name</Label>
          <Input required value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Category</Label>
          <Input value={formData.category} placeholder="e.g. Tools, Electronics" onChange={e => setFormData({ ...formData, category: e.target.value })} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Price</Label>
          <Input type="number" step="0.01" required value={formData.price} onChange={e => setFormData({ ...formData, price: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Initial Stock</Label>
          <Input type="number" required value={formData.stockQuantity} onChange={e => setFormData({ ...formData, stockQuantity: e.target.value })} />
        </div>
      </div>
      <div className="space-y-2">
        <Label>SKU (Optional)</Label>
        <Input value={formData.sku} onChange={e => setFormData({ ...formData, sku: e.target.value })} />
      </div>
      <Button type="submit" className="w-full" disabled={mutation.isPending}>Add Product</Button>
    </form>
  );
}

export default function AdminDashboard() {
  const { data: jobs, isLoading: jobsLoading } = useJobs();
  const { data: users, isLoading: usersLoading } = useUsers();
  const { data: transactions, isLoading: transLoading } = useTransactions();
  const createJob = useCreateJob();
  const createUser = useCreateUser();

  const [search, setSearch] = useState("");
  const [jobOpen, setJobOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);

  // Stats calculation
  const totalJobs = jobs?.length || 0;
  const activeJobs = jobs?.filter(j => j.status === 'in_progress').length || 0;
  const completedJobs = jobs?.filter(j => j.status === 'completed').length || 0;
  const totalWorkers = users?.filter(u => u.role === 'worker').length || 0;

  // Chart Data preparation
  const jobsByStatus = [
    { name: 'Pending', value: jobs?.filter(j => j.status === 'not_started').length || 0, color: '#94a3b8' },
    { name: 'In Progress', value: activeJobs, color: '#3b82f6' },
    { name: 'Completed', value: completedJobs, color: '#10b981' },
  ];

  if (jobsLoading || usersLoading || transLoading) {
    return <div className="h-screen w-full flex items-center justify-center">Loading dashboard...</div>;
  }

  return (
    <LayoutShell title="Admin Dashboard">
      <div className="space-y-8">
        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Briefcase} title="Total Jobs" value={totalJobs} subtext="+12% from last month" color="blue" />
          <StatCard icon={Activity} title="Active Jobs" value={activeJobs} subtext="Currently running" color="amber" />
          <StatCard icon={Users} title="Active Workers" value={totalWorkers} subtext="On shift now" color="emerald" />
          <StatCard 
            icon={DollarSign} 
            title="Total Revenue" 
            value={`€${transactions?.reduce((acc, t) => t.type === 'income' ? acc + parseFloat(t.amount) : acc - parseFloat(t.amount), 0).toFixed(2)}`} 
            subtext="From all completed jobs" 
            color="purple" 
          />
        </div>

        {/* Charts and Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="col-span-1 lg:col-span-2 shadow-sm border-slate-200">
            <CardHeader>
              <CardTitle>Job Performance</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={jobsByStatus}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'white', borderRadius: '8px', border: '1px solid #e2e8f0' }}
                  />
                  <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={50} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          
          <Card className="col-span-1 shadow-sm border-slate-200">
            <CardHeader>
              <CardTitle>Job Status Distribution</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={jobsByStatus}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {jobsByStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Area */}
        <Tabs defaultValue="jobs" className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList className="bg-slate-100 p-1">
              <TabsTrigger value="jobs" className="px-6">Jobs</TabsTrigger>
              <TabsTrigger value="workers" className="px-6">Workers</TabsTrigger>
              <TabsTrigger value="inventory-tracking" className="px-6">Inventory Tracking</TabsTrigger>
              <TabsTrigger value="mall" className="px-6">Mall</TabsTrigger>
              <TabsTrigger value="attendance" className="px-6">Attendance</TabsTrigger>
              <TabsTrigger value="financials" className="px-6">Financials</TabsTrigger>
            </TabsList>
            
            <div className="flex gap-2">
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="Search..." 
                  className="pl-9 bg-white"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <Dialog open={jobOpen} onOpenChange={setJobOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
                    <Plus className="mr-2 h-4 w-4" /> New Job
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Create New Job</DialogTitle>
                  </DialogHeader>
                  <CreateJobForm onSuccess={() => setJobOpen(false)} users={users || []} createJob={createJob} />
                </DialogContent>
              </Dialog>
              
              <Dialog open={userOpen} onOpenChange={setUserOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="border-slate-300">
                    <Users className="mr-2 h-4 w-4" /> Add Worker
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Worker</DialogTitle>
                  </DialogHeader>
                  <CreateUserForm onSuccess={() => setUserOpen(false)} createUser={createUser} />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <TabsContent value="jobs" className="space-y-4">
            <DailyProductStats jobs={jobs || []} />
            <div className="grid grid-cols-1 gap-4">
              {jobs?.filter(j => j.title.toLowerCase().includes(search.toLowerCase())).map((job) => (
                <JobRow key={job.id} job={job} />
              ))}
              {jobs?.length === 0 && (
                <div className="text-center py-12 text-slate-500">No jobs found</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="inventory-tracking">
            <Card>
              <CardHeader>
                <CardTitle>Inventory Tracking by Worker</CardTitle>
                <CardDescription>Detailed history of assigned and returned products per job and worker</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 uppercase font-medium text-[11px] tracking-wider">
                      <tr>
                        <th className="px-6 py-4">Product Name</th>
                        <th className="px-6 py-4">Worker</th>
                        <th className="px-6 py-4">Job Title</th>
                        <th className="px-6 py-4">Quantity</th>
                        <th className="px-6 py-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {jobs?.flatMap((job: any) => 
                        (job.items || []).map((item: any) => ({
                          ...item,
                          jobTitle: job.title,
                          workerName: job.assignedTo?.name || "Unassigned"
                        }))
                      ).filter((item: any) => 
                        item.product?.name.toLowerCase().includes(search.toLowerCase()) ||
                        item.workerName.toLowerCase().includes(search.toLowerCase()) ||
                        item.jobTitle.toLowerCase().includes(search.toLowerCase())
                      ).map((item, idx) => (
                        <tr key={`${item.id}-${idx}`} className="hover:bg-slate-50/50">
                          <td className="px-6 py-4 font-medium text-slate-900">{item.product?.name}</td>
                          <td className="px-6 py-4">{item.workerName}</td>
                          <td className="px-6 py-4">{item.jobTitle}</td>
                          <td className="px-6 py-4 font-mono">{item.quantity}</td>
                          <td className="px-6 py-4 flex gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Edit Product Instance</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                  <div className="space-y-2">
                                    <Label>Quantity</Label>
                                    <Input 
                                      type="number" 
                                      defaultValue={item.quantity}
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        if (!isNaN(val)) {
                                          apiRequest("PATCH", `/api/job-items/${item.id}`, { quantity: val }).then(() => {
                                            queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
                                          });
                                        }
                                      }}
                                    />
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Label>Mark as Returned</Label>
                                    <Button 
                                      variant={item.returned ? "default" : "outline"}
                                      size="sm"
                                      onClick={() => {
                                        apiRequest("PATCH", `/api/job-items/${item.id}`, { returned: !item.returned }).then(() => {
                                          queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
                                        });
                                      }}
                                    >
                                      {item.returned ? "Returned" : "In Use"}
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                            {item.returned ? (
                              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-orange-100 text-orange-700">
                                <ArrowLeftRight className="h-3 w-3" /> Returned
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-100 text-blue-700">
                                <Package className="h-3 w-3" /> Assigned
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                      {(!jobs || jobs.length === 0) && (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center text-slate-500 italic">No inventory tracking data available</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workers">
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 uppercase font-medium">
                      <tr>
                        <th className="px-6 py-4">Name</th>
                        <th className="px-6 py-4">Role</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">Username</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users?.filter(u => u.name.toLowerCase().includes(search.toLowerCase())).map((user) => (
                        <tr key={user.id} className="hover:bg-slate-50/50">
                          <td className="px-6 py-4 font-medium text-slate-900">{user.name}</td>
                          <td className="px-6 py-4 capitalize">{user.role}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                              user.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {user.active ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-slate-500">{user.username}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mall">
            <MallManagement />
          </TabsContent>

          <TabsContent value="financials">
             <Card>
               <CardHeader>
                 <CardTitle>Recent Transactions</CardTitle>
               </CardHeader>
               <CardContent>
                 <div className="space-y-4">
                   {transactions?.map((t) => (
                     <div key={t.id} className="flex justify-between items-center p-4 border rounded-lg hover:bg-slate-50">
                       <div>
                         <p className="font-medium text-slate-900">{t.description || "Transaction"}</p>
                         <p className="text-sm text-slate-500">{format(new Date(t.date!), 'PPP')}</p>
                       </div>
                       <div className={`font-bold font-mono ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                         {t.type === 'income' ? '+' : '-'}${t.amount}
                       </div>
                     </div>
                   ))}
                 </div>
               </CardContent>
             </Card>
          </TabsContent>
          <TabsContent value="attendance">
            <Card>
              <CardHeader>
                <CardTitle>Worker Attendance</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <AttendanceTable />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </LayoutShell>
  );
}

function AttendanceTable() {
  const [date, setDate] = useState<Date>(new Date());
  const { data: attendance, isLoading: attendanceLoading } = useQuery<any[]>({ queryKey: ["/api/attendance/all"] });
  const { data: users, isLoading: usersLoading } = useUsers();

  if (attendanceLoading || usersLoading) return <div className="p-8 text-center">Loading attendance...</div>;

  const workers = users?.filter(u => u.role === 'worker') || [];
  
  const attendanceForDate = attendance?.filter(a => 
    a.checkIn && isSameDay(new Date(a.checkIn), date)
  ) || [];

  const stats = workers.map(worker => {
    const records = attendanceForDate.filter(a => a.userId === worker.id);
    return {
      worker,
      records
    };
  });

  return (
    <div className="space-y-4">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5 text-slate-500" />
              <h3 className="font-bold">Attendance for {format(date, 'PPP')}</h3>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => {
                const csvContent = "Worker,Status,Check In,Check Out,Total Time\n" + 
                  stats.map(s => {
                    const r = s.records[0];
                    return `${s.worker.name},${r ? 'Present' : 'Absent'},${r ? format(new Date(r.checkIn), 'HH:mm:ss') : '-'},${r?.checkOut ? format(new Date(r.checkOut), 'HH:mm:ss') : '-'},${r?.totalHours || '-'}`;
                  }).join("\n");
                const blob = new Blob([csvContent], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `attendance-${format(date, 'yyyy-MM-dd')}.csv`;
                a.click();
              }}>
                Export CSV
              </Button>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(date, "PPP")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(d) => d && setDate(d)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 px-4 pb-4">
        <Card className="bg-green-50/50 border-green-100">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-green-600 mb-1">
              <CheckCircle className="h-4 w-4" />
              <span className="text-xs font-bold uppercase">Checked In</span>
            </div>
            <p className="text-2xl font-bold">{stats.filter(s => s.records.length > 0).length}</p>
          </CardContent>
        </Card>
        <Card className="bg-red-50/50 border-red-100">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-red-600 mb-1">
              <XCircle className="h-4 w-4" />
              <span className="text-xs font-bold uppercase">Absent/Not Yet</span>
            </div>
            <p className="text-2xl font-bold">{stats.filter(s => s.records.length === 0).length}</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-50/50 border-blue-100">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-blue-600 mb-1">
              <Clock className="h-4 w-4" />
              <span className="text-xs font-bold uppercase">Total Shifts</span>
            </div>
            <p className="text-2xl font-bold">{attendanceForDate.length}</p>
          </CardContent>
        </Card>
      </div>

      <div className="overflow-x-auto border-t">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 uppercase font-medium text-[11px] tracking-wider">
            <tr>
              <th className="px-6 py-4">Worker</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Check In</th>
              <th className="px-6 py-4">Check Out</th>
              <th className="px-6 py-4">Total Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {stats.map(({ worker, records }) => (
              <React.Fragment key={worker.id}>
                {records.length > 0 ? (
                  records.map((a, idx) => (
                    <tr key={a.id} className="hover:bg-slate-50/50 group">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-900">{idx === 0 ? worker.name : ""}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-green-100 text-green-700">
                          <CheckCircle className="h-3 w-3" /> Present
                        </span>
                      </td>
                      <td className="px-6 py-4 font-mono text-xs">{format(new Date(a.checkIn), 'HH:mm:ss')}</td>
                      <td className="px-6 py-4 font-mono text-xs">
                        {a.checkOut ? format(new Date(a.checkOut), 'HH:mm:ss') : <span className="text-orange-500 font-bold">ACTIVE</span>}
                      </td>
                      <td className="px-6 py-4 text-slate-500 font-mono text-xs">
                        {a.checkIn && a.checkOut 
                          ? `${Math.round((new Date(a.checkOut).getTime() - new Date(a.checkIn).getTime()) / (1000 * 60))} min`
                          : '-'}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr key={worker.id} className="hover:bg-slate-50/50">
                    <td className="px-6 py-4 font-medium text-slate-900">{worker.name}</td>
                    <td className="px-6 py-4" colSpan={4}>
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-400">
                        <XCircle className="h-3 w-3" /> No record
                      </span>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DailyProductStats({ jobs }: { jobs: any[] }) {
  const today = new Date();
  const todayJobs = jobs.filter(j => j.createdAt && isSameDay(new Date(j.createdAt), today));
  
  let assignedCount = 0;
  let returnedCount = 0;
  let soldCount = 0;
  let dailyRevenue = 0;

  todayJobs.forEach(job => {
    (job as any).items?.forEach((item: any) => {
      assignedCount += item.quantity;
      if (item.returned) {
        returnedCount += item.quantity;
      } else if (job.status === 'completed') {
        soldCount += item.quantity;
        dailyRevenue += parseFloat(item.product?.price || "0") * item.quantity;
      }
    });
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="pt-4 pb-4">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Today's Assigned</p>
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4 text-blue-500" />
            <span className="text-xl font-bold">{assignedCount}</span>
          </div>
        </CardContent>
      </Card>
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="pt-4 pb-4">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Today's Returned</p>
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-orange-500" />
            <span className="text-xl font-bold">{returnedCount}</span>
          </div>
        </CardContent>
      </Card>
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="pt-4 pb-4">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Today's Sold</p>
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-green-500" />
            <span className="text-xl font-bold">{soldCount}</span>
          </div>
        </CardContent>
      </Card>
      <Card className="bg-green-50 border-green-100">
        <CardContent className="pt-4 pb-4">
          <p className="text-[10px] font-bold text-green-600 uppercase tracking-wider mb-1">Today's Revenue</p>
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-green-600" />
            <span className="text-xl font-bold text-green-700">€{dailyRevenue.toFixed(2)}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ icon: Icon, title, value, subtext, color }: any) {
  const colorMap: any = {
    blue: "bg-blue-100 text-blue-600",
    amber: "bg-amber-100 text-amber-600",
    emerald: "bg-emerald-100 text-emerald-600",
    purple: "bg-purple-100 text-purple-600",
  };

  return (
    <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
            <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
          </div>
          <div className={`p-3 rounded-xl ${colorMap[color]}`}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
        <p className="text-xs text-slate-400 mt-4 font-medium">{subtext}</p>
      </CardContent>
    </Card>
  );
}

function JobRow({ job }: { job: any }) {
  const updateJob = useUpdateJob();

  return (
    <Card className="hover:shadow-md transition-shadow group">
      <CardContent className="p-6 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-1">
            <h4 className="text-lg font-bold text-slate-900 truncate">{job.title}</h4>
            <StatusBadge status={job.status} />
          </div>
          <div className="flex flex-wrap gap-4 text-sm text-slate-500 mt-2">
            <div className="flex items-center gap-1">
              <Building2 className="w-4 h-4" />
              {job.client || 'No Client'}
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              {job.location || 'No Location'}
            </div>
            {job.assignedTo && (
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                {job.assignedTo.name}
              </div>
            )}
          </div>
          
          {job.items && job.items.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Job Inventory Status</p>
              <div className="flex flex-wrap gap-2">
                {job.items.map((item: any) => (
                  <div key={item.id} className={cn(
                    "text-xs px-2 py-1 rounded border flex items-center gap-2",
                    item.returned ? "bg-orange-50 border-orange-100 text-orange-700" : "bg-slate-50 border-slate-100"
                  )}>
                    <Package className="w-3 h-3" />
                    <span>{item.product?.name} (x{item.quantity})</span>
                    {item.returned && (
                      <span className="flex items-center gap-1 font-bold text-[10px] uppercase">
                        <CheckCircle className="w-3 h-3" /> Returned by {job.assignedTo?.name}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          {job.status !== 'completed' && (
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => updateJob.mutate({ id: job.id, status: 'completed' })}
            >
              Mark Complete
            </Button>
          )}
          <Button size="sm" variant="ghost">Details</Button>
        </div>
      </CardContent>
    </Card>
  );
}

function CreateJobForm({ onSuccess, users, createJob }: any) {
  const { data: products } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const [formData, setFormData] = useState({
    title: "",
    client: "",
    location: "",
    assignedToId: "",
    description: "",
    paymentAmount: "",
  });
  const [selectedProducts, setSelectedProducts] = useState<{ id: number, quantity: number }[]>([]);
  const [productSearch, setProductSearch] = useState("");

  const filteredProducts = products?.filter(p => 
    (p.name?.toLowerCase().includes(productSearch.toLowerCase()) || 
     p.category?.toLowerCase().includes(productSearch.toLowerCase()))
  );

  const addProductToSelection = (id: string) => {
    const pid = parseInt(id);
    if (!selectedProducts.find(p => p.id === pid)) {
      setSelectedProducts([...selectedProducts, { id: pid, quantity: 1 }]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    createJob.mutate({
      ...formData,
      assignedToId: formData.assignedToId ? parseInt(formData.assignedToId) : undefined,
      paymentAmount: formData.paymentAmount || "0",
    }, {
      onSuccess: async (job: any) => {
        // Create job items for each selected product
        for (const p of selectedProducts) {
          await apiRequest("POST", "/api/job-items", {
            jobId: job.id,
            productId: p.id,
            quantity: p.quantity
          });
        }
        queryClient.invalidateQueries({ queryKey: ["/api/products"] });
        onSuccess();
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Job Title</Label>
          <Input 
            required
            value={formData.title} 
            onChange={e => setFormData({...formData, title: e.target.value})} 
          />
        </div>
        <div className="space-y-2">
          <Label>Client</Label>
          <Input 
            value={formData.client} 
            onChange={e => setFormData({...formData, client: e.target.value})} 
          />
        </div>
      </div>

      <div className="space-y-4 p-4 border rounded-lg bg-slate-50">
        <Label className="text-slate-900 font-bold">Assign Products for Job</Label>
        <div className="flex gap-2">
          <Input 
            placeholder="Search products..." 
            value={productSearch}
            onChange={(e) => setProductSearch(e.target.value)}
            className="flex-1 bg-white"
          />
          <Select onValueChange={addProductToSelection}>
            <SelectTrigger className="bg-white w-[180px]">
              <SelectValue placeholder="Add..." />
            </SelectTrigger>
            <SelectContent>
              {filteredProducts?.map(p => (
                <SelectItem key={p.id} value={String(p.id)}>{p.name} ({p.stockQuantity})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          {selectedProducts.map((sp, idx) => {
            const product = products?.find(p => p.id === sp.id);
            return (
              <div key={sp.id} className="flex items-center justify-between bg-white p-2 border rounded">
                <span className="text-sm font-medium">{product?.name}</span>
                <div className="flex items-center gap-2">
                  <Input 
                    type="number" 
                    className="w-20 h-8" 
                    min="1" 
                    max={product?.stockQuantity}
                    value={sp.quantity} 
                    onChange={e => {
                      const newSelection = [...selectedProducts];
                      newSelection[idx].quantity = parseInt(e.target.value);
                      setSelectedProducts(newSelection);
                    }}
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-destructive"
                    onClick={() => setSelectedProducts(selectedProducts.filter(p => p.id !== sp.id))}
                  >
                    <Plus className="h-4 w-4 rotate-45" />
                  </Button>
                </div>
              </div>
            );
          })}
          {selectedProducts.length === 0 && <p className="text-xs text-slate-500 italic">No products assigned yet.</p>}
        </div>
      </div>

      <div className="space-y-2">
        <Label>Location</Label>
        <Input 
          value={formData.location} 
          onChange={e => setFormData({...formData, location: e.target.value})} 
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Assign To</Label>
          <Select 
            value={formData.assignedToId} 
            onValueChange={v => setFormData({...formData, assignedToId: v})}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select worker" />
            </SelectTrigger>
            <SelectContent>
              {users.filter((u: any) => u.role === 'worker').map((u: any) => (
                <SelectItem key={u.id} value={String(u.id)}>{u.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Payment Amount</Label>
          <Input 
            type="number"
            value={formData.paymentAmount} 
            onChange={e => setFormData({...formData, paymentAmount: e.target.value})} 
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Description</Label>
        <Input 
          value={formData.description} 
          onChange={e => setFormData({...formData, description: e.target.value})} 
        />
      </div>

      <div className="flex justify-end pt-4">
        <Button type="submit" disabled={createJob.isPending}>
          {createJob.isPending ? "Creating..." : "Create Job"}
        </Button>
      </div>
    </form>
  );
}

function CreateUserForm({ onSuccess, createUser }: any) {
  const [formData, setFormData] = useState({
    name: "",
    username: "",
    password: "",
    role: "worker",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createUser.mutate(formData, { onSuccess });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Full Name</Label>
        <Input 
          required
          value={formData.name} 
          onChange={e => setFormData({...formData, name: e.target.value})} 
        />
      </div>
      <div className="space-y-2">
        <Label>Username</Label>
        <Input 
          required
          value={formData.username} 
          onChange={e => setFormData({...formData, username: e.target.value})} 
        />
      </div>
      <div className="space-y-2">
        <Label>Password</Label>
        <Input 
          required
          type="password"
          value={formData.password} 
          onChange={e => setFormData({...formData, password: e.target.value})} 
        />
      </div>
      <div className="space-y-2">
        <Label>Role</Label>
        <Select 
          value={formData.role} 
          onValueChange={v => setFormData({...formData, role: v})}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="worker">Worker</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex justify-end pt-4">
        <Button type="submit" disabled={createUser.isPending}>
          {createUser.isPending ? "Creating..." : "Add User"}
        </Button>
      </div>
    </form>
  );
}
