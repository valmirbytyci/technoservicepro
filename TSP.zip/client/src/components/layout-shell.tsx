import { ReactNode } from "react";
import { useAuth } from "@/hooks/use-auth";
import { LogOut, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

import technoLogo from "@assets/image_1767599883034.png";

export function LayoutShell({ children, title }: { children: ReactNode; title: string }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <header className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src={technoLogo} alt="LogiTrack" className="h-10 w-auto rounded-lg" />
            <div className="h-6 w-px bg-slate-200" />
            <span className="text-slate-500 font-medium">{title}</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="hidden md:block text-sm text-slate-500">
              {new Date().toLocaleDateString('en-GB', { timeZone: 'Europe/Tirane' })}
            </span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <User className="h-5 w-5 text-slate-600" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none">
                    {user?.name && <p className="font-medium">{user.name}</p>}
                    {user?.role && (
                      <p className="w-[200px] truncate text-xs text-muted-foreground capitalize">
                        {user.role}
                      </p>
                    )}
                  </div>
                </div>
                <DropdownMenuItem onClick={() => logout()} className="text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}
