# LogiTrack - Logistics Management System

## Overview

LogiTrack is a role-based logistics management web application designed for managing jobs, workers, time tracking, and financial transactions. The system provides separate dashboards for admins (full visibility and control) and workers (limited access, task-focused). Key features include check-in/check-out time tracking, job lifecycle management, financial tracking (income/expenses), and statistics reporting. The system is timezone-aware, configured for Tirana, Albania.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style variant)
- **Build Tool**: Vite with custom plugins for Replit integration
- **Charts**: Recharts for dashboard visualizations

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **Authentication**: Passport.js with local strategy, session-based auth using express-session
- **Session Storage**: MemoryStore (development), with connect-pg-simple available for production

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Migrations**: Drizzle Kit for schema migrations (`npm run db:push`)
- **Validation**: Drizzle-Zod for schema-to-validation integration

### API Design
- **Contract Definition**: Shared route contracts in `shared/routes.ts` using Zod schemas
- **Pattern**: Type-safe API contracts shared between frontend and backend
- **Authentication**: Session-based with role-based access control (admin/worker)

### Project Structure
```
├── client/           # React frontend
│   └── src/
│       ├── components/   # UI components (shadcn/ui)
│       ├── hooks/        # Custom React hooks for data fetching
│       ├── pages/        # Page components
│       └── lib/          # Utilities and query client
├── server/           # Express backend
│   ├── routes.ts     # API route handlers
│   ├── storage.ts    # Database access layer
│   └── auth.ts       # Authentication setup
├── shared/           # Shared code between frontend/backend
│   ├── schema.ts     # Drizzle database schema
│   └── routes.ts     # API contract definitions
└── migrations/       # Database migrations
```

### Role-Based Access Control
- **Admin**: Full access to all features including managing jobs, workers, viewing financials, and exporting reports
- **Worker**: Restricted to assigned jobs, updating job status, check-in/out, and viewing own work hours

### Data Models
- **Users**: Authentication and role management (admin/worker)
- **Jobs**: Task management with status tracking, assignments, and payment info
- **Attendance**: Time tracking with check-in/check-out functionality
- **Transactions**: Financial tracking for income and expenses

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable

### UI Component Libraries
- **Radix UI**: Headless UI primitives for accessible components
- **shadcn/ui**: Pre-styled component library built on Radix

### Key Runtime Dependencies
- **express**: Web server framework
- **passport / passport-local**: Authentication
- **drizzle-orm**: Database ORM
- **zod**: Runtime type validation
- **date-fns**: Date manipulation
- **recharts**: Dashboard charts

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret key for session encryption (optional, has default)